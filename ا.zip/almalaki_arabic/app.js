// ملف تشغيل تطبيق الملكي — النسخة العربية الأولية
const $ = (selector) => document.querySelector(selector);

$("#languageBtn").addEventListener("click", () => {
  alert("سيبقى التطبيق بالعربية في هذه النسخة. سنفعّل التبديل إلى الإنجليزية ضمن تطوير لاحق.");
});

const savedTheme = localStorage.getItem("almalaki-theme");
if (savedTheme === "dark") document.body.classList.add("dark");
$("#themeBtn").textContent = document.body.classList.contains("dark") ? "☀" : "☾";
$("#themeBtn").addEventListener("click", () => {
  document.body.classList.toggle("dark");
  const dark = document.body.classList.contains("dark");
  localStorage.setItem("almalaki-theme", dark ? "dark" : "light");
  $("#themeBtn").textContent = dark ? "☀" : "☾";
});

const savedPrefs = JSON.parse(localStorage.getItem("almalaki-preferences") || "{}");
if (savedPrefs.country) $("#countrySelect").value = savedPrefs.country;
if (savedPrefs.stream) $("#streamSelect").value = savedPrefs.stream;

$("#saveSetup").addEventListener("click", () => {
  localStorage.setItem("almalaki-preferences", JSON.stringify({
    country: $("#countrySelect").value,
    stream: $("#streamSelect").value
  }));
  $("#setupMessage").textContent = "تم حفظ اختياراتك على هذا الجهاز.";
});

const features = {
  library: { title: "مكتبة الدروس", text: "ستظهر هنا الدروس والملخصات بعد أن نضيف المحتوى التعليمي الموثوق.", icon: "▤" },
  ai: { title: "المساعد الذكي", text: "هذه واجهة تجريبية فقط. سنربطها لاحقًا بمساعد ذكي بعد اختيار خدمة مناسبة ومراجعة التكلفة والخصوصية.", icon: "✧" },
  quiz: { title: "اختبر نفسك", text: "سنضيف هنا أسئلة تدريبية مع تصحيح فوري وشرح للإجابة.", icon: "✓" },
  plan: { title: "خطة المراجعة", text: "سنضيف هنا جدولًا أسبوعيًا بسيطًا يمكن تعديله حسب وقتك وموادك.", icon: "◷" }
};

document.querySelectorAll("[data-feature]").forEach(button => {
  button.addEventListener("click", () => {
    const feature = features[button.dataset.feature];
    $("#dialogTitle").textContent = feature.title;
    $("#dialogText").textContent = feature.text;
    $("#dialogIcon").textContent = feature.icon;
    $("#dialogExtra").innerHTML = "";
    if (button.dataset.feature === "ai") {
      const note = document.createElement("p");
      note.textContent = "لن يرسل هذا النموذج سؤالك إلى الإنترنت؛ ميزة الإجابة الذكية لم تُفعّل بعد.";
      $("#dialogExtra").append(note);
    }
    $("#featureDialog").showModal();
  });
});

$("#closeDialog").addEventListener("click", () => $("#featureDialog").close());
$("#featureDialog").addEventListener("click", event => {
  if (event.target === $("#featureDialog")) $("#featureDialog").close();
});
$("#year").textContent = new Date().getFullYear();
